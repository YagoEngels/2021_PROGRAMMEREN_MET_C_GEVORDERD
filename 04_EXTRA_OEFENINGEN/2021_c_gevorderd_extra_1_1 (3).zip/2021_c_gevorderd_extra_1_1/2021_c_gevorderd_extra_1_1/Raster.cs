﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_gevorderd_extra_1_1
{
    class Raster
    {
        List<ObjectParant> vakken = new List<ObjectParant>();
        List<int> indexen = new List<int>();
        List<int> indexenRots = new List<int>();
        List<int> indexenDiamand = new List<int>();
        List<bool> puntBehaald = new List<bool>();

        public int aiFun { get; set; }
        public int aiFunA { get; set; }

        public string leegVak = "|";
        public int punten { get; set; }

        public Raster()
        {
        }


        public void maakRaster()
        {
            Random random = new Random();
            for(int i = 0; i < 101; i++)
            {
                vakken.Add(new LeegObject());
            }

            for(int i = 0; i < 15; i++)
            {
                int a = random.Next(1,100) ;
                vakken[a] = new Rots();
                indexenRots.Add(a);
            }

            for(int i = 0; i < 15; i++)
            {
                int a = random.Next(1, 100);
                foreach(int j in indexenRots)
                {
                    if(j == a)
                    {
                        a = random.Next(1, 100);
                    }
                }
                vakken[a] = new Diamant();
                indexenDiamand.Add(a);
                puntBehaald.Add(false);
            }

        }
        public void updateRoster(CursorPlayer c)
        {
            if (indexen.Count != 0)
            {
                vakken[indexen[indexen.Count - 1]] = new LeegObject();
            }
            vakken[c.index] = c;
            indexen.Add(c.index);
            if (onDiaEnPunt(c)){
                punten++;
            }
        }
        public void show()
        {
            Console.WriteLine("+---+---+---+---+---+---+---+---+---+---+");
            for (int i = 1; i < 101; i++)
            {
                if(i % 10 == 0 && i != 0)
                {
                    Console.Write(vakken[i].ToString() + "|");
                    Console.WriteLine("\n+---+---+---+---+---+---+---+---+---+---+");
                } else
                {
                    Console.Write(vakken[i].ToString());
                }
            }
        }
        public void showEveryting()
        {
            for(int i = 1; i < 101; i++)
            {
                Console.WriteLine(vakken[i].ToString() + "\t" + i);
            }
        }
        public void showEveryting2()
        {
            for(int i = 0; i < 101; i++)
            {
                Console.WriteLine(indexen[i]);
            }
        }
        public void showEveryting3Rots()
        {
            for(int i = 0; i < indexenRots.Count; i++)
            {
                Console.WriteLine(indexenRots[i]);
            }
        }
        public bool isRockUp(CursorPlayer c)
        {
            bool uit = false;
            Console.WriteLine(c.index);
            foreach(int i in indexenRots)
            {
                //Console.WriteLine(i);

                if ((c.index - 10) == i)
                {
                    uit = true;
                }
            }
            return uit;
        }
        public bool isRockLeft(CursorPlayer c)
        {
            bool uit = false;
            Console.WriteLine(c.index);
            foreach(int i in indexenRots)
            {
                //Console.WriteLine(i);

                if ((c.index - 1) == i)
                {
                    uit = true;
                }
            }
            return uit;
        }
        public bool isRockDown(CursorPlayer c)
        {
            bool uit = false;
            Console.WriteLine(c.index);
            foreach(int i in indexenRots)
            {
                if ((c.index + 10) == i)
                {
                    uit = true;
                }
            }
            return uit;
        }
        public bool isRockRight(CursorPlayer c)
        {
            bool uit = false;
            //Console.WriteLine(c.index);
            foreach(int i in indexenRots)
            {
                if ((c.index + 1) == i)
                {
                    uit = true;
                }
            }
            return uit;
        }
        public bool onDiaEnPunt(CursorPlayer c)
        {
            bool uit = false;
            for(int i = 0; i < indexenDiamand.Count; i++)
            {
                if(c.index == indexenDiamand[i] && puntBehaald[i] == false)
                {
                    uit = true;
                    puntBehaald[i] = true;
                }
            }
            return uit;
        }
        public void MoveRightWithEx(CursorPlayer c)
        {
            if (!isRockRight(c))
            {
                c.CursorMoveRight();
            }
        }
        public void MoveLeftWithEx(CursorPlayer c)
        {
            if (!isRockLeft(c))
            {
                c.CursorMoveLeft();
            }
        }
        public void MoveUpWithEx(CursorPlayer c)
        {
            if (!isRockUp(c))
            {
                c.CursorMoveTop();
            }
        }
        public void MoveDownWithEx(CursorPlayer c)
        {
            if (!isRockDown(c))
            {
                c.CursorMoveDown();
            }
        }
    }
}
