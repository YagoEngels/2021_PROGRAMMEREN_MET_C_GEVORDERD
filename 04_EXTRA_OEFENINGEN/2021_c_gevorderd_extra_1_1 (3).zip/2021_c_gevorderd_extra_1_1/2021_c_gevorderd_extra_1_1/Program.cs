﻿using System;
using System.Collections.Generic;

namespace _2021_c_gevorderd_extra_1_1
{
    class Program
    {
        static ConsoleKey key;
        static CursorPlayer cursor = new CursorPlayer();
        static Raster raster = new Raster();
        static void Main(string[] args)
        {
            raster.maakRaster();
            raster.updateRoster(cursor);
            raster.show();
            //raster.showEveryting3Rots();
            Menu();

            //raster.showEveryting(); //dit is een functie die alles toont van index tot welk model er in zit
        }

        static void Menu()
        {
            Console.WriteLine("+---------------------------------------+");
            Console.WriteLine("|aantal punten : " + raster.punten);
            Console.WriteLine("|aantal zetten : " + cursor.aantalZetten);
            Console.WriteLine("|                 (up)                  |");
            Console.WriteLine("|      (left)            (right)        |");
            Console.WriteLine("|                (down)                 |");
            Console.WriteLine("| (enter) for AI                        |");
            Console.WriteLine("+---------------------------------------+");

            key = Console.ReadKey().Key;

            switch (key)
            {
                case ConsoleKey.UpArrow:
                    raster.MoveUpWithEx(cursor);
                    heiligeDrievuldigheidsFun();
                    break;

                case ConsoleKey.LeftArrow:
                    raster.MoveLeftWithEx(cursor);
                    heiligeDrievuldigheidsFun();
                    break;

                case ConsoleKey.RightArrow:
                    raster.MoveRightWithEx(cursor);
                    heiligeDrievuldigheidsFun();
                    break;

                case ConsoleKey.DownArrow:
                    raster.MoveDownWithEx(cursor);
                    heiligeDrievuldigheidsFun();
                    break;

                case ConsoleKey.Escape:
                    Console.WriteLine("press [Enter] to end");
                    Console.ReadKey();
                    break;
                default:
                    Console.WriteLine("er is iets fout gegaan druk op een knop");
                    Console.ReadKey();
                    heiligeDrievuldigheidsFun();
                    break;
            }
        }

        static void heiligeDrievuldigheidsFun()
        {
            Console.Clear();
            raster.updateRoster(cursor);
            raster.show();
            //Console.WriteLine(raster.isRockUp(cursor));
            //Console.WriteLine(raster.aiFun);
            //Console.WriteLine(raster.aiFunA);
            Menu();
        }
    }
}
