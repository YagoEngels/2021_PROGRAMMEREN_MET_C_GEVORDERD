﻿using System;
using System.Collections.Generic;

namespace _2021_c_gevorderd_extra_1_1
{
    class Program
    {
        static ConsoleKey key;
        static CursorPlayer cursor = new CursorPlayer();
        static Raster raster = new Raster();
        static void Main(string[] args)
        {
            raster.maakRaster();
            raster.updateRoster(cursor);
            raster.show();
            //raster.showEveryting3Rots();
            Menu();

            //raster.showEveryting(); //dit is een functie die alles toont van index tot welk model er in zit
        }

        static void Menu()
        {
            Console.WriteLine("+---------------------------------------+");
            Console.WriteLine("|aantal punten :                        |");
            Console.WriteLine("|aantal zetten :                        |");
            Console.WriteLine("|                 (up)                  |");
            Console.WriteLine("|      (left)            (right)        |");
            Console.WriteLine("|                (down)                 |");
            Console.WriteLine("+---------------------------------------+");

            key = Console.ReadKey().Key;

            switch (key)
            {
                case ConsoleKey.UpArrow:
                    if (!raster.isRockUp(cursor))
                    {
                        cursor.CursorMoveTop();
                    }
                    heiligeDrievuldigheidsFun();
                    break;

                case ConsoleKey.LeftArrow:
                    cursor.CursorMoveLeft();
                    heiligeDrievuldigheidsFun();
                    break;

                case ConsoleKey.RightArrow:
                    cursor.CursorMoveRight();
                    heiligeDrievuldigheidsFun();
                    break;

                case ConsoleKey.DownArrow:
                    cursor.CursorMoveDown();
                    heiligeDrievuldigheidsFun();
                    break;

                case ConsoleKey.Escape:
                    Console.WriteLine("press [Enter] to end");
                    Console.ReadKey();
                    break;

                default:
                    Console.WriteLine("er is iets fout gegaan druk op een knop");
                    Console.ReadKey();
                    heiligeDrievuldigheidsFun();
                    break;
            }
        }

        static void heiligeDrievuldigheidsFun()
        {
            Console.Clear();
            raster.updateRoster(cursor);
            raster.show();
            Console.WriteLine(raster.isRockUp(cursor));
            Menu();
        }
    }
}
