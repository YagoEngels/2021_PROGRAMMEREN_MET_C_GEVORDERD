﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_gevorderd_extra_1_1
{
    class CursorPlayer : ObjectParant
    {
        public string tekening = "| > ";
        public int index;

        public CursorPlayer()
        {
            index = 1;
        }

        public override string ToString()
        {
            return tekening;
        }



        public void CursorMoveTop()
        {
            if (index > 10)
            {
                index -= 10;
            }
        }
        public void CursorMoveRight()
        {
            if (index % 10 != 0)
            {
                index += 1;
            }
        }
        public void CursorMoveLeft()
        {
            if (index % 10 != 1)
            {
                index -= 1;
            }
        }
        public void CursorMoveDown()
        {
            if (index < 91)
            {
                index += 10;
            }
        }
    }
}
