﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_gevorderd_extra_1_1
{
    class Raster
    {
        List<ObjectParant> vakken = new List<ObjectParant>();
        List<int> indexen = new List<int>();
        List<int> indexenRots = new List<int>();
        List<int> indexenDiamand = new List<int>();
        public string leegVak = "|";

        public Raster()
        {
        }


        public void maakRaster()
        {
            Random random = new Random();
            for(int i = 0; i < 101; i++)
            {
                vakken.Add(new LeegObject());
            }

            for(int i = 0; i < 15; i++)
            {
                int a = random.Next(1,100) ;
                vakken[a] = new Rots();
                indexenRots.Add(a);
            }

            for(int i = 0; i < 15; i++)
            {
                int a = random.Next(1,100);
                vakken[a] = new Diamant();
                indexenDiamand.Add(a);
            }

        }

        public void updateRoster(CursorPlayer c)
        {
            if (indexen.Count != 0)
            {
                vakken[indexen[indexen.Count - 1]] = new LeegObject();
            }
            vakken[c.index] = c;
            indexen.Add(c.index);
        }
        public void show()
        {
            Console.WriteLine("+---+---+---+---+---+---+---+---+---+---+");
            for (int i = 1; i < 101; i++)
            {
                if(i % 10 == 0 && i != 0)
                {
                    Console.Write(vakken[i].ToString() + "|");
                    Console.WriteLine("\n+---+---+---+---+---+---+---+---+---+---+");
                } else
                {
                    Console.Write(vakken[i].ToString());
                }
            }
        }

        public void showEveryting()
        {
            for(int i = 1; i < 101; i++)
            {
                Console.WriteLine(vakken[i].ToString() + "\t" + i);
            }
        }

        public void showEveryting2()
        {
            for(int i = 0; i < 101; i++)
            {
                Console.WriteLine(indexen[i]);
            }
        }

        public Boolean isRockUp(CursorPlayer c)
        {
            Boolean uit = false;

            foreach(int i in indexenRots)
            {
                if((c.index -= 10) == i)
                {
                    uit = true;
                }
            }
            return uit;
        }
    }
}
