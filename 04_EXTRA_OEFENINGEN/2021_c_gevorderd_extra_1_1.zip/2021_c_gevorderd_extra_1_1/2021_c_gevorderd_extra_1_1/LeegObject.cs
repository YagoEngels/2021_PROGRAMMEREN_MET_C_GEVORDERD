﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_gevorderd_extra_1_1
{
    class LeegObject : ObjectParant
    {
        public string tekening { get; set; }

        public LeegObject()
        {
            tekening = "|   ";
        }

        public override string ToString()
        {
            return tekening;
        }
    }
}
