﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_gevorderd_extra_1_1
{
    class CursorPlayer : ObjectParant
    {
        public string tekening = "| > ";
        public int index;

        public CursorPlayer()
        {
            index = 1;
        }

        public override string ToString()
        {
            return tekening;
        }
    }
}
