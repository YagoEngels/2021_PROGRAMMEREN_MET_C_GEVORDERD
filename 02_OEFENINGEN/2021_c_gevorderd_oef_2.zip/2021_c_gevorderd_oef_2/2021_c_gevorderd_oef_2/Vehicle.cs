﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_gevorderd_oef_2
{
    class Vehicle
    {
        Engine engine = new Engine();
        public string serieNummer { get; set; }

        public Vehicle(string serieNr)
        {
            serieNummer = serieNr;
        }

        public Vehicle(string serieNr,bool isRunning)
        {
            serieNummer = serieNr;
            engine.Running = isRunning;
        }

        public void Stop()
        {
            if (engine.Running == true)
            {
                engine.Running = false;
            }
        }

        public void Start()
        {
            if(engine.Running == false)
            {
                engine.Running = true;
            }
        }
        public virtual string getZin()
        {
            string uit = "";
            uit += "\t\t-\tSerienummer:\t" + serieNummer + "\tEngine is running:\t" + engine.Running;
            return uit;
        }
    }
}
