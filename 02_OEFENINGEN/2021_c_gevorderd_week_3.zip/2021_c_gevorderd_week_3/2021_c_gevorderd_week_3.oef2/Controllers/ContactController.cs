﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace _2021_c_gevorderd_week_3.oef2.Controllers
{
    public class ContactController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Locations()
        {
            return View();
        }
        public string CallCenter()
        {
            return "ring ring";
        }
    }
}
