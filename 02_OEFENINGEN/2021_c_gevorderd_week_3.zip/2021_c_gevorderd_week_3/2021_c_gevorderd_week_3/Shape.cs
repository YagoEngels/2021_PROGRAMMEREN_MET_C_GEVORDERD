﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_gevorderd_week_3.oef1
{
    abstract class Shape
    {
        public string GetDescription()
        {
            return "Ik ben een vorm.";
        }

        public abstract double CalculateSurface();
        public abstract double CalculateCircumference();
    }
}
