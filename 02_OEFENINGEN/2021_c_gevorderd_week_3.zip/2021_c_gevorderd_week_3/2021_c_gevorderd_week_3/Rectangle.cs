﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_gevorderd_week_3.oef1
{
    class Rectangle : Shape
    {
        public double Width { get; set; }
        public Double Height { get; set; }

        public override double CalculateCircumference()
        {
            return (Width + Height) * 2;
        }

        public override double CalculateSurface()
        {
            throw new NotImplementedException();
        }
    }
}
