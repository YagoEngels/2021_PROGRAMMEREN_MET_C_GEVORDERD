﻿using System;
using System.Collections.Generic;

namespace _2021_c_gevorderd_week_3.oef1
{
    class Program
    {
        static void Main(string[] args)
        {
            Circle circle = new Circle() { Radius = 5 };

            Rectangle rectangle = new Rectangle() { Width = 2, Height = 6 };

            List<Shape> shapes = new List<Shape>();
            shapes.Add(circle);
            shapes.Add(rectangle);
        }
    }
}
