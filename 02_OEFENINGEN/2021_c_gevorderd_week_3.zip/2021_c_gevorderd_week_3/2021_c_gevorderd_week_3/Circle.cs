﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_gevorderd_week_3.oef1
{
    class Circle : Shape
    {
        public double Radius { get; set; }
        public override double CalculateSurface()
        {
            return Math.Pow(Radius, 2) * Math.PI;
        }

        public override double CalculateCircumference()
        {
            return 2 * Radius * Math.PI;
        }
    }
}
