﻿using System;
using System.Collections.Generic;

#nullable disable

namespace _2021_c_gevorderd_week_4_oef1.Models
{
    public partial class BuildVersion
    {
        public byte SystemInformationId { get; set; }
        public string DatabaseVersion { get; set; }
        public DateTime VersionDate { get; set; }
        public DateTime ModifiedDate { get; set; }
    }
}
