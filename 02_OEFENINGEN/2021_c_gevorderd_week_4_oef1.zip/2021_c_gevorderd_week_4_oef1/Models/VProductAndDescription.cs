﻿using System;
using System.Collections.Generic;

#nullable disable

namespace _2021_c_gevorderd_week_4_oef1.Models
{
    public partial class VProductAndDescription
    {
        public int ProductId { get; set; }
        public string Name { get; set; }
        public string ProductModel { get; set; }
        public string Culture { get; set; }
        public string Description { get; set; }
    }
}
