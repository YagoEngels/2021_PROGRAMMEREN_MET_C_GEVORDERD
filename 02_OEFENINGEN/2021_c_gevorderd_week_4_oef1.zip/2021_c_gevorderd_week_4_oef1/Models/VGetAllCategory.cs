﻿using System;
using System.Collections.Generic;

#nullable disable

namespace _2021_c_gevorderd_week_4_oef1.Models
{
    public partial class VGetAllCategory
    {
        public string ParentProductCategoryName { get; set; }
        public string ProductCategoryName { get; set; }
        public int? ProductCategoryId { get; set; }
    }
}
