﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using _2021_c_gevorderd_week_4_oef1.Models;

namespace _2021_c_gevorderd_week_4_oef1.Controllers
{
    public class CustomerController : Controller
    {

        AdventureWorksLT2019Context db = new AdventureWorksLT2019Context();

        // GET: CustomerController
        public ActionResult Index()
        {
            var data = (from c in db.Customers
                        orderby c.ModifiedDate descending
                        select c).Take(20);
            return View(data);

        }

        // GET: CustomerController/Details/5
        public ActionResult Details(int id)
        {
            var data = (from c in db.Customers
                        orderby c.ModifiedDate descending
                        where c.CustomerId == id
                        select c).Take(20);
            return View(data.FirstOrDefault());
        }

        // GET: CustomerController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: CustomerController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                Customer c = new Customer();
                c.FirstName = collection["Firstname"];
                c.LastName = collection["Lastname"];
                c.FirstName = collection["Firstname"];
                c.FirstName = collection["Firstname"];

                c.ModifiedDate = DateTime.Now;
                c.PasswordHash = "aaa";
                c.PasswordSalt = "bbb";

                db.Add(c);
                db.SaveChanges();

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: CustomerController/Edit/5
        public ActionResult Edit(int id)
        {

            var data = (from c in db.Customers
                        orderby c.ModifiedDate descending
                        where c.CustomerId == id
                        select c).Take(20);

            return View(data.FirstOrDefault());
        }

        // POST: CustomerController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                Customer data = (from c in db.Customers
                            where (c.CustomerId == id)
                            select c).FirstOrDefault();

                if(data != null)
                {
                    data.FirstName = collection["Firstname"];
                    data.ModifiedDate = DateTime.Now;
                    db.SaveChanges();
                    return RedirectToAction(nameof(Index));
                }
                return View();
            }
            catch
            {
                return View();
            }
        }

        // GET: CustomerController/Delete/5
        public ActionResult Delete(int id)
        {

            Customer data = (from c in db.Customers
                             where (c.CustomerId == id)
                             select c).FirstOrDefault();


            return View(data);
        }

        // POST: CustomerController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {

                Customer data = (from c in db.Customers
                                 where (c.CustomerId == id)
                                 select c).FirstOrDefault();

                db.Remove(data);
                db.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
