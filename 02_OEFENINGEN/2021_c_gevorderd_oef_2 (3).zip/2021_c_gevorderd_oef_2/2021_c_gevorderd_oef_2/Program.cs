﻿using System;
using System.Collections.Generic;

namespace _2021_c_gevorderd_oef_2
{
    class Program
    {
        static int keuze;
        static List<Vehicle> vehicles;
        static List<Bike> bikes;
        static List<BikeRack> bikeRacks;
        static void Main(string[] args)
        {
            vehicles = new List<Vehicle>();
            bikes = new List<Bike>();
            bikeRacks = new List<BikeRack>();
            Menu();
        }

        static void Menu()
        {
            Console.WriteLine("+---------------------------------+");
            Console.WriteLine("| 1. auto toevoegen               |");
            Console.WriteLine("| 2. moto toevoegen               |");
            Console.WriteLine("| 3. overzicht weergeven          |");
            Console.WriteLine("| 4. auto starten                 |");
            Console.WriteLine("| 5. moto starten                 |");
            Console.WriteLine("| 6. bike rack toevoegen          |");
            Console.WriteLine("| 7. City bike toevoegen          |");
            Console.WriteLine("| 8. ebike toevoegen              |");
            Console.WriteLine("| 9. bikes overzicht              |");
            Console.WriteLine("| 10. sluiten                     |");
            Console.WriteLine("| 10. sluiten                     |");
            Console.WriteLine("| 10. sluiten                     |");
            Console.WriteLine("| 10. sluiten                     |");
            Console.WriteLine("+---------------------------------+");

            Console.Write("keuze : ");
            keuze = int.Parse(Console.ReadLine());

            switch (keuze)
            {
                case 1:
                    Console.Write("serieunummer:");
                    vehicles.Add(new Car(Console.ReadLine()));
                    Console.Write("Press ENTER:");
                    Console.ReadKey();
                    Console.Clear();
                    Menu();
                    break;

                case 2:
                    Console.Write("serieunummer:");
                    vehicles.Add(new MotorCycle(Console.ReadLine()));
                    Console.Write("Press ENTER:");
                    Console.ReadKey();
                    Console.Clear();
                    Menu();
                    break;

                case 3:
                    Console.WriteLine("\t-\tOverzicht");
                    foreach(Vehicle v in vehicles)
                    {
                        Console.WriteLine(v.GetDescription());
                    }
                    Console.Write("Press ENTER:");
                    Console.ReadKey();
                    Console.Clear();
                    Menu();
                    break;

                case 4 & 5:
                    Console.Write("geef mij een serienummer:");
                    string serienr = Console.ReadLine();
                    foreach (Vehicle v in vehicles)
                    {
                        if (v.SerieNr.Equals(serienr))
                        {
                            v.Start();
                        } else
                        {
                            Console.WriteLine("deze serienr is fout of bestaat nog niet");
                        }
                    }
                    Console.Write("Press ENTER:");
                    Console.ReadKey();
                    Console.Clear();
                    Menu();
                    break;
                case 6:
                    Console.Write("serieunummer:");
                    bikeRacks.Add(new BikeRack(Console.ReadLine(),int.Parse(Console.ReadLine())));
                    Console.Write("Press ENTER:");
                    Console.ReadKey();
                    Console.Clear();
                    Menu();
                    break;
                case 7:
                    Console.Write("serieunummer:");
                    bikes.Add(new CityBike(Console.ReadLine()));
                    Console.Write("Press ENTER:");
                    Console.ReadKey();
                    Console.Clear();
                    Menu();
                    break;
                case 8:
                    Console.Write("serieunummer:");
                    bikes.Add(new EBike(Console.ReadLine()));
                    Console.Write("Press ENTER:");
                    Console.ReadKey();
                    Console.Clear();
                    Menu();
                    break;
                case 9:
                    Console.WriteLine("\t-\tOverzicht fietsen");
                    foreach (Bike b in bikes)
                    {
                        Console.WriteLine(b.GetDescription());
                    }
                    Console.Write("Press ENTER:");
                    Console.ReadKey();
                    Console.Clear();
                    Menu();
                    break;
                case 10:
                    Console.Write("BY BY");
                    break;
                case 11:
                    Console.Write("BY BY");
                    break;
                case 12:
                    Console.Write("BY BY");
                    break;
                case 13:
                    Console.Write("BY BY");
                    break;
            }
        }
    }
}
