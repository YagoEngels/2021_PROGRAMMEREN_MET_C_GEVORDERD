﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_gevorderd_oef_2
{
    class Vehicle : IIdentfy,IGearMotorized
    {
        public string SerieNr { get; set; }
        public int NrOfGears { get; set; }
        public Engine Motorblok { get; set; }
        public int HorserPower { get; set; }

        public Vehicle(string serieNr)
        {
            SerieNr = serieNr;
            Motorblok = new Engine();
        }

        public Vehicle(string serieNr,bool isRunning)
        {
            SerieNr = serieNr;
            Motorblok = new Engine();
            Motorblok.Running = isRunning;
        }

        public void Stop()
        {
            if (Motorblok.Running == true)
            {
                Motorblok.Running = false;
            }
        }

        public void Start()
        {
            if(Motorblok.Running == false)
            {
                Motorblok.Running = true;
            }
        }

        public virtual string GetDescription()
        {
            string uit = "";
            uit += "\t\t-\tSerienummer:\t" + SerieNr + "\tEngine is running:\t" + Motorblok.Running;
            return uit;
        }

        public void ChangeGear()
        {
            throw new NotImplementedException();
        }

        public void accelarate()
        {
            throw new NotImplementedException();
        }
    }
}
