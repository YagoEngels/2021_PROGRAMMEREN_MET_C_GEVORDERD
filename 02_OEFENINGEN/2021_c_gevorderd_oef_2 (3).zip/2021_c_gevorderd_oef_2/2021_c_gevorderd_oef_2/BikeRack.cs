﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_gevorderd_oef_2
{
    class BikeRack : Accessories
    {
        public int NrOfBikes { get; set; }
        public BikeRack(string s, int nrOfBikes) : base(s)
        {
            NrOfBikes = nrOfBikes;
        }

        public override string GetDescription()
        {
            return "deze accesoire met als serienr " + SerieNr + " is een bike rack met " + NrOfBikes + " aantal fietsen op";
        }

    }
}
