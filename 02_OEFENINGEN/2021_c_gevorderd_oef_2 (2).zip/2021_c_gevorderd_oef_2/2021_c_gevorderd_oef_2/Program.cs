﻿using System;
using System.Collections.Generic;

namespace _2021_c_gevorderd_oef_2
{
    class Program
    {
        static int keuze;
        static List<Vehicle> vehicles;
        static void Main(string[] args)
        {
            vehicles = new List<Vehicle>();
            Menu();
        }

        static void Menu()
        {
            Console.WriteLine("+---------------------------------+");
            Console.WriteLine("| 1. auto toevoegen               |");
            Console.WriteLine("| 2. moto toevoegen               |");
            Console.WriteLine("| 3. overzicht weergeven          |");
            Console.WriteLine("| 4. auto starten                 |");
            Console.WriteLine("| 5. moto starten                 |");
            Console.WriteLine("| 6. sluiten                      |");
            Console.WriteLine("+---------------------------------+");

            Console.Write("keuze : ");
            keuze = int.Parse(Console.ReadLine());

            switch (keuze)
            {
                case 1:
                    Console.Write("serieunummer:");
                    vehicles.Add(new Car(Console.ReadLine()));
                    Console.Write("Press ENTER:");
                    Console.ReadLine();
                    Console.Clear();
                    Menu();
                    break;

                case 2:
                    Console.Write("serieunummer:");
                    vehicles.Add(new MotorCycle(Console.ReadLine()));
                    Console.Write("Press ENTER:");
                    Console.ReadLine();
                    Console.Clear();
                    Menu();
                    break;

                case 3:
                    Console.WriteLine("\t-\tOverzicht");
                    foreach(Vehicle v in vehicles)
                    {
                        Console.WriteLine(v.ToString());
                    }
                    Console.Write("Press ENTER:");
                    Console.ReadLine();
                    Console.Clear();
                    Menu();
                    break;

                case 4 & 5:
                    Console.Write("geef mij een serienummer:");
                    string serienr = Console.ReadLine();
                    foreach (Vehicle v in vehicles)
                    {
                        if (v.serieNummer.Equals(serienr))
                        {
                            v.Start();
                        } else
                        {
                            Console.WriteLine("deze serienr is fout of bestaat nog niet");
                        }
                    }
                    Console.Write("Press ENTER:");
                    Console.ReadLine();
                    Console.Clear();
                    Menu();
                    break;
                case 6:
                    Console.Write("BY BY");
                    break;
            }
        }
    }
}
