﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_gevorderd_oef_2
{
    class MotorCycle : Vehicle
    {
        public bool SadleOpen;
        public MotorCycle(string serieNr) : base(serieNr)
        {
            SadleOpen = false;
        }

        public string OpenSadle()
        {
            if(SadleOpen)
            {
                return "het zadel is open";
            }
            else
            {
                return "het zadel is gesloten";
            }
        }
        public override string ToString()
        {
            return base.ToString() + "\t(moto)";
        }
    }
}
