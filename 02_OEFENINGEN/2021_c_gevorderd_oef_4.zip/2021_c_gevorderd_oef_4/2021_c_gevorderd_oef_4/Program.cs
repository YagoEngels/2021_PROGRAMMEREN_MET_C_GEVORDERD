﻿using System;

namespace _2021_c_gevorderd_oef_4
{
    class Program
    {
        static void Main(string[] args)
        {
            LobbyMonitor lobby = new LobbyMonitor();
            Console.WriteLine(lobby.ShowInformatioin());

            Console.WriteLine(((IInfoDisplay)lobby).showWarning()   );
        }
    }
}
