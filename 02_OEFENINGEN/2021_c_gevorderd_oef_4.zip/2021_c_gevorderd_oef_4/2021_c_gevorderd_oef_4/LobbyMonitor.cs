﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_gevorderd_oef_4
{
    class LobbyMonitor : IInfoDisplay
    {
        public string ShowError()
        {
            return "fout opgetreden";
        }

        public string ShowInformatioin()
        {
            return "ucll is gesloten op 25/12";
        }
    }
}
