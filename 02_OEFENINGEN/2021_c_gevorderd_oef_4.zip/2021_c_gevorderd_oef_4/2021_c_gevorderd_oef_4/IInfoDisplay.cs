﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_gevorderd_oef_4
{
    interface IInfoDisplay
    {
        public string ShowError();
        public string ShowInformatioin();
        public string showWarning()
        {
            return "brand alarm";
        }
    }
}
