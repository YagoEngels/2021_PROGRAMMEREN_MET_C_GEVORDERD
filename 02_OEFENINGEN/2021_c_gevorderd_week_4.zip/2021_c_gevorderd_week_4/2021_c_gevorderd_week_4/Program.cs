﻿using System;

namespace _2021_c_gevorderd_week_4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
