﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using _2021_c_gevorderd_week_4_oef_1.Models;

namespace _2021_c_gevorderd_week_4_oef_1.Controllers
{
    public class ContactController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Locations()
        {
            List<GeoLocation> geoLocations = new List<GeoLocation>();
            GeoLocation geo = new GeoLocation() { city = "PARIS", country = "FRANCE" };
            GeoLocation geo1 = new GeoLocation() { city = "LONDON", country = "UK" };
            GeoLocation geo2 = new GeoLocation() { city = "chicago", country = "us" };
            GeoLocation geo3 = new GeoLocation() { city = "brussel", country = "belgie" };

            geoLocations.Add(geo);
            geoLocations.Add(geo1);
            geoLocations.Add(geo2);
            geoLocations.Add(geo3);
            ViewData["hq"] = geoLocations;
            return View();
        }
        public IActionResult CallCenter()
        {
            return View();
        }
        public IActionResult Vehicles()
        {
            return RedirectToAction("Index" , "Vehicle");
        }
        public IActionResult Details()
        {
            return View();
        }
        public IActionResult Modify()
        {
            return View();
        }
    }
}
