﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using _2021_c_gevorderd_week_4_oef_1.Models;

namespace _2021_c_gevorderd_week_4_oef_1.Controllers
{
    public class VehicleController : Controller
    {

        List<Vehicle> showroom = new List<Vehicle>();

        public VehicleController()
        {
            showroom.Add(new Car() { Brand = "bmw", Color = "RED", NrOfDoors = 5, SerialNr = " qsds", Type = "a1" });
            showroom.Add(new MotorCycle() { Brand = "bmw", Color = "RED", IsSelfBalancing = true, SerialNr = " aze", Type = "a1" });
        }


        // GET: VehicleController
        public ActionResult Index()
        {
            return View(showroom);
        }

        // GET: VehicleController/Details/5
        public ActionResult Details(string id)
        {
            Vehicle car = showroom.Find(item => item.SerialNr == id);
            if(car != null)
            {
                return View(car);
            } else
            {
                return View();
            }
        }

        // GET: VehicleController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: VehicleController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: VehicleController/Edit/5
        public ActionResult Edit(string id)
        {
            Vehicle car = showroom.Find(item => item.SerialNr == id);
            if (car != null)
            {
                return View(car);
            }
            else
            {
                return View();
            }
        }

        // POST: VehicleController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: VehicleController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: VehicleController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
