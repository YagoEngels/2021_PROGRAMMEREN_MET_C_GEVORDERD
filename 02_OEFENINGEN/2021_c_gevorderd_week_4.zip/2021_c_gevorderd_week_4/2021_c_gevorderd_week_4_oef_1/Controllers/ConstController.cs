﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace _2021_c_gevorderd_week_4_oef_1.Controllers
{
    public class ConstController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
