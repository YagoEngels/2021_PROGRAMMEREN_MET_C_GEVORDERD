﻿using _2021_c_gevorderd_week_4_oef_1.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace _2021_c_gevorderd_week_4_oef_1.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        //dit zijn al de buttons in de navigatie
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Privacy()
        {
            ViewData["developer"] = "Johan Roosen";
            TempData["expected"] = "January 2022";

            return RedirectToAction("Index", "Const");
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
