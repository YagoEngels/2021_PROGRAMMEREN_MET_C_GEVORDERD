﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace _2021_c_gevorderd_week_4_oef_1.Models
{
    public class MotorCycle : Vehicle
    {
        public bool IsSelfBalancing { get; set; }
    }
}
