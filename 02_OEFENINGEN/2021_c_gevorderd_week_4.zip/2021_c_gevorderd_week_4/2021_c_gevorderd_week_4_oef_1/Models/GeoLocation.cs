﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace _2021_c_gevorderd_week_4_oef_1.Models
{
    public class GeoLocation
    {
        public string city { get; set; }
        public string country { get; set; }
        public GeoLocation()
        {

        }
    }
}
