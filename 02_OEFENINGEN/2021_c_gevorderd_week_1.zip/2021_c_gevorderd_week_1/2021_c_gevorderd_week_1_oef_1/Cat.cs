﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_gevorderd_week_1_oef_1
{
    class Cat : Mammal
    {
        public Cat()
        {
            Console.WriteLine("moew moew is mijn eerste zin");
        }
            public Cat(int age) : base(age)
            {
                Console.WriteLine("kat met een leeftijd van jaar");
            }
        public void meaw()
        {
            Console.WriteLine("lolllll ik ben een cat");
        }
    }
}
