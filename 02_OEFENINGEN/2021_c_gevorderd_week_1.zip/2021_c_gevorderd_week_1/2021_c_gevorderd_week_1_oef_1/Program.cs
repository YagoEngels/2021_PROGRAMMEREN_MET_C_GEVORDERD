﻿using System;

namespace _2021_c_gevorderd_week_1_oef_1
{
    class Program
    {
        static void Main(string[] args)
        {

            Zoo zooAntwerpen = new Zoo();

            zooAntwerpen.addMamel(new Dog() { Age = 25 });
            zooAntwerpen.addMamel(new Cat());
            zooAntwerpen.addMamel(new Mammal());
            zooAntwerpen.addMamel(new Rabbit());

            Console.WriteLine("\n---------\n");

            Console.WriteLine(zooAntwerpen.getIventory());

            Console.WriteLine("---------\n");

            Dog d = new Dog();
            Console.WriteLine(d.getDescription());

            Console.WriteLine("---------\n");

            Platypus platypus = new Platypus();
            Console.WriteLine(platypus.getDescription());
        }
    }
}
