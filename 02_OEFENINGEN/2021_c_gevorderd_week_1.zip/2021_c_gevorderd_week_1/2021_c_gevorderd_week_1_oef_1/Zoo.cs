﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_gevorderd_week_1_oef_1
{
    class Zoo
    {
        List<Mammal> mammals = new List<Mammal>();

        public void addMamel(Mammal mammal)
        {
            mammals.Add(mammal);
        }

        public string getIventory()
        {
            string uit = "";
            foreach(Mammal x in mammals)
            {
                uit = uit + x.getDescription()+"\n";
            }
            return uit;
        }
    }
}
