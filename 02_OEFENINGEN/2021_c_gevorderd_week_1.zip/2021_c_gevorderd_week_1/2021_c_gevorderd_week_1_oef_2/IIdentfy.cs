﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_gevorderd_week_1_oef_2
{
    interface IIdentfy
    {
        public string SerieNr { get; set; }
        public string GetDescription();
    }
}
