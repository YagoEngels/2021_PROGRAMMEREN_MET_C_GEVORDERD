﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_gevorderd_week_1_oef_2
{
    class CityBike : Bike
    {
        public CityBike(string s) : base(s)
        {

        }

        public override string GetDescription()
        {
            return " dit is een citybike en dus een bike";
        }
    }
}
