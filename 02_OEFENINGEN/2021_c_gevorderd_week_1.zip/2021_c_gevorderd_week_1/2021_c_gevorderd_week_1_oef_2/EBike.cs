﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_gevorderd_week_1_oef_2
{
    class EBike : Bike
    {
        public int WattageSupport { get; set; }

        public EBike(string s):base(s)
        {

        }

        public void ChargeBattery()
        {

        }

        public override string GetDescription()
        {
            return "IK BEN EEN E BIKE";
        }
    }
}
