﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_gevorderd_week_1_oef_2
{
    interface IMotorized
    {
        public Engine Motorblok { get; set; }
        public int HorserPower { get; set; }

        public void accelarate();
    }
}
