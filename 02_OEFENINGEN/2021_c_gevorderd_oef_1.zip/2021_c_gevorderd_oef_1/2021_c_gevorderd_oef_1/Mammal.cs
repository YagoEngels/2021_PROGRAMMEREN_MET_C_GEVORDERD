﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_gevorderd_oef_1
{
    class Mammal
    {
        public string hairColor { get; set; }
        public string name { get; set; }
        public int weight { get; set; }
        public int Age { get; set; }


        public Mammal()
        {
            Console.WriteLine("ik leef nu opeen !!!!!!!");
        }

        public Mammal(int age)
        {
            Age = age;
        }

        public virtual string getDescription()
        {
            return " ik ben een beest";
        }
    }
}
