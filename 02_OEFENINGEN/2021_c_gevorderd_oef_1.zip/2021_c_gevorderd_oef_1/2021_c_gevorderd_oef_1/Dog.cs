﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_gevorderd_oef_1
{
    class Dog : Mammal
    {
        public Dog()
        {
            Console.WriteLine("woef woef is mijn eerste zin");
        }
        public Dog(int age) : base(age)
        {
            Console.WriteLine("hond met een leeftijd");
        }
        public void bark()
        {
            Console.WriteLine("lol ik ben een dogo");
        }

        public override string getDescription()
        {
            string uit = "ik ben een hondbeest";
            return uit;
        }

    }
}
