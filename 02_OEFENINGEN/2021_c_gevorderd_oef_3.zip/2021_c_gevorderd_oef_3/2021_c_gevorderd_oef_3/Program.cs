﻿using System;

namespace _2021_c_gevorderd_oef_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Car car = new Car() { HorsePower = 10, OwnerId = 1234 };
            House house = new House() { serface = 500 , OwnerId = 1 };

            Console.WriteLine("Tax car : " + car.CalcTax());
            Console.WriteLine("Tax house : " + house.CalcTax());
            Console.WriteLine("--------------------------------");
            Console.WriteLine("Total  : " + (car.CalcTax() + house.CalcTax()));
        }
    }
}
