﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_gevorderd_oef_3
{
    interface Itaxable
    {
        public int rate { get; set; }
        double CalcTax();
    }
}
