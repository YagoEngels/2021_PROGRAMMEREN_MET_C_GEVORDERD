﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_gevorderd_oef_3
{
    interface ITaxLoger : Itaxable
    {
        public List<Double> history { get; set; }
    }
}
