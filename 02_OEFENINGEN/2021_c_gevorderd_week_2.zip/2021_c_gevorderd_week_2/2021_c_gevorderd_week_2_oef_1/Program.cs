﻿using System;
using System.Collections.Generic;

namespace _2021_c_gevorderd_week_2_oef_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Car car = new Car() { HorsePower = 10, OwnerId = 1234 };
            House house = new House() { serface = 500, OwnerId = 1 };

            List<Itaxable> itaxables = new List<Itaxable>();
            itaxables.Add(car);
            itaxables.Add(house);

            /*foreach(Itaxable i in itaxables)
            {
                if(i is Car)
                {
                    Console.WriteLine("cp = "+ ((Car)i).HorsePower);
                }
                if(i is House)
                {
                    Console.WriteLine("cp = "+ ((House)i).serface);
                }
            }*/


            /*Console.WriteLine("Tax car : " + car.CalcTax());
            Console.WriteLine("Tax house : " + house.CalcTax());
            Console.WriteLine("--------------------------------");
            Console.WriteLine("Total  : " + (car.CalcTax() + house.CalcTax()));*/
        }

        static public void showTaxOnCons(Itaxable taxitem)
        {
            Console.WriteLine(taxitem.CalcTax());
        }
    }
}
