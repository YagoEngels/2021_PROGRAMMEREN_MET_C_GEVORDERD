﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_gevorderd_week_2_oef_1
{
    class House : Itaxable,IIsOwned
    {
        public int serface { get; set; }
        public int rate { get; set; }
        public int OwnerId { get; set; }

        public double CalcTax()
        {
            return serface * 2.22;
        }
    }
}
