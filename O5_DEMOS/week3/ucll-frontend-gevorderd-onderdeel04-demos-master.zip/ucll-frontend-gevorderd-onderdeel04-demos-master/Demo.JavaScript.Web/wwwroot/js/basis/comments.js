﻿// Dit is een single line commentaar

/*
 * Dit is een multiline commentaar
 */

/* En dit ook natuurlijk.
*/


/* 
 * Eens doornemen als je wat wil lachen: 
 * https://stackoverflow.com/questions/184618/what-is-the-best-comment-in-source-code-you-have-ever-encountered
 */

// Sometimes, I believe the compiler ignores all my comments

// I am not sure if we need this, but too scared to delete. 

// I am not responsible of this code.
// They made me write it, against my will.
