﻿console.log("*** types.js ***");

// boolean
var oneEqualsOne = true;
var earthIsFlat = false;

// string
var hello = "Hello world";
console.log(hello);

// number (geheel getal)
var minAge = 18;
console.log(minAge);

// number (kommagetal)
var temperature = 20.5;
console.log(temperature);

// array
var courses = ["GIAdPG4", "GIAdPG5"];
console.log(courses);
console.log(courses.length);
console.log(courses[0]);
console.log(courses[1]);