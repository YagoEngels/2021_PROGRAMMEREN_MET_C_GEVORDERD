﻿module.exports = {
    entry: {
        basisClassesModules: './src/index.js'
    },
    output: {
        filename: '../wwwroot/js/basis-classes-modules-bundle.js'
    },
    devtool: "source-map"
};