﻿// (!) Normaal zouden de JavaScript bronfiles in /src moeten opgenomen worden maar aangezien deze demo ook
// de niet-webpack variant demonstreert werden de JavaScript bronfiles opgenomen in wwwroot.

import "../wwwroot/js/basis/comments.js";
import "../wwwroot/js/basis/output.js";
import "../wwwroot/js/basis/var-let-const.js";
import "../wwwroot/js/basis/types.js";
import "../wwwroot/js/basis/exceptions.js";
import "../wwwroot/js/basis/conditional.js";
import "../wwwroot/js/basis/loops.js";
import "../wwwroot/js/basis/functions.js";
import "../wwwroot/js/basis/objects.js";
import "../wwwroot/js/basis/math.js";
import "../wwwroot/js/basis/input.js";

import "../wwwroot/js/classes/classes.js";

import "../wwwroot/js/modules/applicatie.js";
