﻿module.exports = {
    entry: {
        versie7: './wwwroot/js/versie6.js'
    },
    output: {
        filename: '../wwwroot/js/versie7.js'
    }
}