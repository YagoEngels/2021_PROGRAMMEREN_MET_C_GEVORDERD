﻿Deze solution bevat 'hybride' oplossingen: je kan deze zowel uitvoeren met Express op Node als met ASP.NET Core.  

Zorg ervoor dat [Node](https://nodejs.org/en/download/) geïnstalleerd is. Dat heb je nodig voor beide varianten.
In de package.json bestanden bij de oplossingen kan je terugvinden welke afhankelijkheden er zijn.
De afhankelijkheid ```concurrently``` wordt gebruikt om npm scripts in parallel uit te voeren.  

Sommige oplossingen bestaan ook uit een deeloplossing zonder webpack (```wwwroot/index.nowebpack.html```) en 
een deeloplossing met webpack (```wwwroot/index.webpack.html```).

Om een oplossing te starten open je eerst een terminal of een command prompt in de directory van de oplossing.

# Uitvoeren met Express

Automatisch (watch mode):
1. ```npm run start-node``` (of ```npm run start```)

Manueel
1. ```npm install```
2. ```npx webpack``` 
3. ```node app.js```

Ga vervolgens naar http://localhost:3000.


# Uitvoeren met ASP.NET Core
Zorg ervoor dat .NET SDK 5.0 of 6.0 geïnstalleerd is.

Automatisch (watch mode):
1. ```npm run start-net```

Manueel
1. ```npm install```
2. ```npx webpack```
3. ```dotnet build```
4. ```dotnet run```

Ga vervolgens naar https://localhost:5001 (of http://localhost:5000).