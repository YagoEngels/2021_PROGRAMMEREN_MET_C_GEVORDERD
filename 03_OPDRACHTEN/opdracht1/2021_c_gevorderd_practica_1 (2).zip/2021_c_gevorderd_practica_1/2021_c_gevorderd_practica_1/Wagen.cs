﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_gevorderd_practica_1
{
    //de eigenschappen
    class Wagen
    {
        public double Catalogusprijs { get; set; }
        public string Nummerplaat { get; set; }

        //de ctor
        public Wagen(double prijs, string nummer)
        {
            Catalogusprijs = prijs;
            Nummerplaat = nummer;
        }

        //vanaf hier de functies 

        public override string ToString()
        {
            return "\t-\tNummerplaat : " + Nummerplaat + "\t-\tCatalogusprijs : " + Catalogusprijs;
        }

        public virtual double Vaa()
        {
            return 0;
        }
    }
}
