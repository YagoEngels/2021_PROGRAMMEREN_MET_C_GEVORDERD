﻿using System;
using System.Collections.Generic;

namespace _2021_c_gevorderd_practica_1
{
    class Program
    {
        //global parameters in deze klasse
        static int keuze = 0;
        static List<Wagen> wagens = new List<Wagen>();
        static double aantalVaa;


        static void Main(string[] args)
        {
            Menu();
        }

        static void Menu()
        {
            Console.WriteLine("** Vaa berekening **");
            Console.WriteLine("1. Voeg een auto toe.");
            Console.WriteLine("2. Overzicht wagens");
            Console.WriteLine("3. Totaal VAA");
            Console.WriteLine("4. Stop programma");
            string keuzeString = Console.ReadLine();
            int.TryParse(keuzeString, out keuze);
                    
            switch (keuze)
            {
                case 1:
                    Console.WriteLine("\tKies een model");
                    Console.WriteLine("\t-\t1. Diesel");
                    Console.WriteLine("\t-\t2. Benzine");

                    int keuze2 = int.Parse(Console.ReadLine());
                    Console.Write("\t-\tNummerplaat : ");
                    string n = Console.ReadLine();
                    Console.Write("\t-\tCatalogusprijs : ");
                    double p = double.Parse(Console.ReadLine());
                    if(keuze2 == 1)
                    {
                        Console.Write("\t-\tNOx : ");
                        double no = double.Parse(Console.ReadLine());
                        wagens.Add(new Dieselwagen(p,n,no));
                    } else if(keuze2 == 2)
                    {
                        Console.Write("\t-\tCO2 : ");
                        double c = double.Parse(Console.ReadLine());
                        wagens.Add(new Dieselwagen(p, n, c));
                    }
                    eindeFun(); 
                    break;
                case 2:
                    Console.WriteLine("\tOverzicht wagens : ");
                    foreach(Wagen x in wagens)
                    {
                        Console.WriteLine(x.ToString());
                    }
                    eindeFun();
                    break;
                case 3:
                    foreach(Wagen w in wagens)
                    {
                        aantalVaa += w.Vaa();
                    }
                    Console.WriteLine("Het totaal te betalen VAA: " + aantalVaa);
                    eindeFun();
                    break;
                case 4:
                    Console.Write("\n[PRESS ENTER]");
                    Console.ReadKey();
                    Console.Clear();
                    break;
                default:
                    Console.WriteLine("Er is een probleem opgetreden , dit is waarschijlijk door \n\t-\tEen fout nummer in te geven , geef een nummer tussen 1 en 4 in.\n\t-\tDoor geen nummer in te geven maar een string");
                    eindeFun();
                    break;

            }
        }

        static void eindeFun()
        {
            Console.Write("\n[PRESS ENTER]");
            Console.ReadKey();
            Console.Clear();
            Menu();
        }
    }
}
