﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_gevorderd_practica_1
{
    class Benzinewagen : Wagen
    {
        //eigenschappen
        public double CO2 { get; set; }

        //ctor
        public Benzinewagen(double prijs, string nummer,int c): base(prijs, nummer)
        {
            CO2 = c;
        }

        //functies
        public override string ToString()
        {
            return base.ToString() + "\t-\tCO2 : " + CO2;
        }

        public override double Vaa()
        {
            return base.Vaa() + Catalogusprijs * CO2 / 1000;
        }
    }
}
