﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_gevorderd_practica_1
{
    class Dieselwagen : Wagen
    {
        //eigenschappen
        public double NOx { get; set; }

        //ctor
        public Dieselwagen(double prijs, string nummer,double nox) : base(prijs, nummer)
        {
            NOx= nox;
        }

        //functies
        public override string ToString()
        {
            return base.ToString() + "\t-\tNOx : " + NOx;
        }

        public override double Vaa()
        {
            return base.Vaa() + Catalogusprijs * NOx / 1000;
        }
    }


}
