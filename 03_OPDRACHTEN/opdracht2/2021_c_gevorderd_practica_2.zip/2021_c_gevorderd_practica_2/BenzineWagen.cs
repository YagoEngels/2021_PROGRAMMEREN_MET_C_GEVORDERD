﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_gevorderd_practica_2
{
    class BenzineWagen : Wagen
    {
        //properties
        private double _CO2;
        public double CO2
        {
            get
            {
                return _CO2;
            }
            set
            {
                _CO2 = value;
            }
        }

        //ctor
        public BenzineWagen(double p, string n, string i, double c) : base(p, n, i)
        {
            CO2 = c;
        }

        //functies
        public override string ToString()
        {
            return base.ToString() + String.Format("\n\tCO2 waarden :\t{0}", CO2);
        }
        public override double VAA()
        {
            double uit = 0;
            uit = Prijs * (CO2 / 1000);
            return uit;
        }
    }
}
