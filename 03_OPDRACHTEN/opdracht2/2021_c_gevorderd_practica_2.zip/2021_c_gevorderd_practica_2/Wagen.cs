﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_gevorderd_practica_2
{
    abstract class Wagen : ICompanyAsset
    {
        //properties
        private double _Prijs;
        private string _Nummerplaat;
        public double Prijs
        {
            get{ return _Prijs; }
            set
            {
                if(value > 0)
                {
                    _Prijs = value;
                } else
                {
                    _Prijs = 0;
                }
            }
        }
        public string Nummerplaat
        {
            get { return _Nummerplaat; }
            set { _Nummerplaat = value; }
        }

        public string CompanyId { get; set; }

        //ctor
        public Wagen( double p ,string n , string i)
        {
            Prijs = p;
            Nummerplaat = n;
            CompanyId = i;
        }

        //functies
        public override string ToString()
        {
            return String.Format( "eigenschappen auto :\n\tprijs :\t{0}\n\tnummerplaat :\t{1}", Prijs, Nummerplaat);
        }
        public abstract double VAA();
    }
}
