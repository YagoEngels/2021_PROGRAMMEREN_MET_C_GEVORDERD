﻿using System;

namespace _2021_c_gevorderd_practica_2
{
    class Program
    {
        static void Main(string[] args)
        {
            DieselWagen wagen = new DieselWagen(15, "ojooj",15);
            Console.WriteLine(wagen.ToString());
        }
    }
}
