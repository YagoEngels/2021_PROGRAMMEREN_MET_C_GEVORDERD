﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_gevorderd_practica_2
{
    class Laptop : ICompanyAsset
    {
        //properties 
        private double _LeasingBedrag;
        public double LeasingBedrag
        {
            get
            {
                return _LeasingBedrag;
            }
            set
            {
                _LeasingBedrag = value;
            }
        }

        public string CompanyId { get; set; }

        //ctor
        public Laptop( double l ,string i)
        {
            LeasingBedrag = l;
            CompanyId = i;
        }

        //functies
        public override string ToString()
        {
            return String.Format("eigenschappen laptop :\n\tLeasing bedrag :\t{0}",  LeasingBedrag);
        }

        public double VAA()
        {
            double uit = 0;
            uit = (LeasingBedrag / 20) * 12;
            return uit;
        }
    }
}
