﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021_c_gevorderd_practica_2
{
    class DieselWagen : Wagen
    {
        //properties
        private double _NOx;
        public double NOx { get { return _NOx; } set { _NOx = value; } }

        //ctor  
        public DieselWagen(double p, string n, string i, double nox) : base(p, n,i)
        {
            NOx = nox;
        }

        //functies
        public override string ToString()
        {
            return base.ToString() + String.Format("\n\tNOx waarden :\t{0}",NOx);
        }
        public override double VAA()
        {
            double uit = 0;
            uit = Prijs * (NOx / 1000);
            return uit;
        }
    }
}
